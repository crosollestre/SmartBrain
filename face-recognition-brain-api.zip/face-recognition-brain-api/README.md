# SmartBrain-api - v1
Final project for Udemy course

1. Clone this repo
2. Run `npm install`
3. Run `npm start`

** Make sure you use postgreSQL instead of mySQL for this code base.
